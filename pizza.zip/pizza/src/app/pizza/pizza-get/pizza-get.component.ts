import { Component, OnInit } from '@angular/core';
import { Pizza } from '../pizza';
import { ActivatedRoute, Router } from '@angular/router';
import { PizzaService } from '../service/pizza-service.service';

@Component({
  selector: 'app-piz-get',
  templateUrl: './pizza-get.component.html',
  styleUrls: ['./pizza-get.component.css']
})
export class PizzaGetComponent implements OnInit {
  pizzas:Pizza[]=[];
  selectedPiz:Pizza;
  constructor(private route:ActivatedRoute,private service:PizzaService,private router:Router) { }


  ngOnInit() {
  this.service.getPizzas()
  .subscribe(pizzaList=>this.pizzas=pizzaList);  
}
onSelection(piz:Pizza){
  console.log("in on Selection : "+piz);
  this.selectedPiz=piz;
  this.router.navigateByUrl('/piz/edit/'+piz.pizzaId);
  console.log("update")
}
}


export class Pizza {
    _id?:number;
    pizzaId:number;
    pizzaName:string;
    price:number;
    _v?:number;
}

import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { PizzaService } from '../service/pizza-service.service';

@Component({
  selector: 'app-piz-add',
  templateUrl: './pizza-add.component.html',
  styleUrls: ['./pizza-add.component.css']
})
export class PizzaAddComponent implements OnInit {
  angForm:FormGroup;
  constructor(private fb:FormBuilder,private pizService:PizzaService) {
    this.createForm();
   }

  ngOnInit() {
  }
  createForm(){
    this.angForm=this.fb.group({
      pizzaId:['',Validators.required],
      pizzaName:['',Validators.required],
      price:['',Validators.required]
    });
  }
  addPizza(pizzaId,pizzaName,price){
    this.pizService.addPizza(pizzaId,pizzaName,price);
  }
}

import { Component, OnInit, Input } from '@angular/core';
import { Pizza } from '../pizza';
import { ActivatedRoute } from '@angular/router';
import { PizzaService } from '../service/pizza-service.service';

@Component({
  selector: 'app-piz-update',
  templateUrl: './pizza-edit.component.html',
  styleUrls: ['./pizza-edit.component.css']
})
export class PizzaUpdateComponent implements OnInit {
  @Input()
  pizza:Pizza;
  
  constructor(private route:ActivatedRoute,private service:PizzaService) { }

  ngOnInit() {
     }
  updatePizza(pizzaId:any,price:any){
    this.service.updatePizza(pizzaId,price);
  }

}
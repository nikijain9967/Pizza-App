import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Pizza } from '../pizza';

@Injectable({
  providedIn: 'root'
})
export class PizzaService {
  //default URI to call express service is :http://localhost:4000/emp
  uri='http://localhost:4000/piz';
  constructor(private httpClient:HttpClient) { }
  //http://localhost:4000/emp/allPizza
  getPizzas():Observable<Pizza[]>{
    return this.httpClient.get<Pizza[]>(`${this.uri}`+'/allPiz');
  }
  
  addPizza(id,name,price){
    let piz={
      pizzaId:id,
      pizzaName:name,
      price:price
    };
    return this.httpClient.post(`${this.uri}`+'/addPiz',piz)
    .subscribe(res=>console.log("New Pizza Added successfully"));
  }

      //'http://localhost:4000/delete/:pizzaId'
      deletePizza(pizzaId:number)
      {
      this.httpClient.delete(`${this.uri}`+'/delete/'+`${pizzaId}`)
      .subscribe(res=>console.log("Pizza deleted Successfully"));
      }

      updatePizza(pizzaId,price):any{
        return this.httpClient.put(`${this.uri}`+'/update/'+pizzaId+'/'+price,{})
        .subscribe(res=>console.log(pizzaId+"updated form database"))
   }
 
 
  

  }
  


import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PizzaAddComponent } from './pizza/pizza-add/pizza-add.component';
import { PizzaDeleteComponent } from './pizza/pizza-delete/pizza-delete.component';
import { PizzaUpdateComponent } from './pizza/pizza-edit/pizza-edit.component';


const routes: Routes = [
  {path:'piz/create',component:PizzaAddComponent},
  {path:'piz/delete/:pizzaId', component:PizzaDeleteComponent},
  {path:'piz/edit/:pizzaId',component:PizzaUpdateComponent}
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

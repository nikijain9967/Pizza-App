//step1: include all modules
const express=require('express');
const cors=require('cors');
const bodyparser=require('body-parser');
const mongoose=require('mongoose');
const dbconfig=require('./DB');
const apiPizzaRouter=require('./server/api-pizza.route');
const app=express();
const path=require('path');
//step2: configuration of databases
mongoose.Promise=global.Promise;
mongoose.connect(dbconfig.DB,{useNewUrlParser:true}).then(
    ()=>console.log("Database connected"),
    (err)=>console.log("Failed to connect database")
);

//step3:handling app static resources and api call
app.use(bodyparser.json());//json handling 
app.use(cors());
//path.join(_dirname, 'dist/appname)
//public:folder which contains all static resources
//{.html,.jpg,.png,.css,.js} we will keep in one folder call public
app.use(express.static(path.join(__dirname,'public')));
app.get('/',(req,resp)=>{
    resp.sendFile("index.html");
});
// to call apiEmployee route
app.use('/piz', apiPizzaRouter);
//step4: starting server
app.listen(4000,()=>{console.log("Server listening at 4000")});